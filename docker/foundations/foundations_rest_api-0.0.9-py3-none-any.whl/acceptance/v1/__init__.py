"""
Copyright (C) DeepLearning Financial Technologies Inc. - All Rights Reserved
Unauthorized copying, distribution, reproduction, publication, use of this file, via any medium is strictly prohibited
Proprietary and confidential
Written by Dariem Perez <d.perez@dessa.com>, 11 2018
"""

from acceptance.v1.test_jobs_listing_endpoint import TestJobsListingEndpoint
from acceptance.v1.test_queued_jobs_endpoint import TestQueuedJobsEndpoint
