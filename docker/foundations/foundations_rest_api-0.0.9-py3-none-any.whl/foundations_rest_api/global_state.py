from foundations_rest_api.app_manager import AppManager

app_manager = AppManager()
